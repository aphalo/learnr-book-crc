There is a single .tex file for the whole book as this is what knitr creates from the .Rnw files, which are separate for each chapter.

These LaTeX source files should be enough to rebuild the PDF without running the R code chunks. Except for the attached .sty files all other .sty files are from the MikTeX distribution and available from CTAN. I update installed packages regularly, so not more than a week behind MikTeX releases. Lucida Bright and other Lucida fonts are used. They are the distribution from TUG. An icon font is also used. Quite many macros used throughout the manuscript are defined in usingr.sty.

For the first edition, the front matter was supplied to me and I assembled the final file with Acrobat Pro X, for which I have a licence. This may be again the easiest route.

I do not include the .Rnw files as there are two code chunks that require a physical measuring device attached to the computer through USB.

XeLaTeX is used together with biber. .bib files are in biblatex format.
